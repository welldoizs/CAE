-- CAE FINAL — migração necessária para a etapa final de moderação.
-- Execute este arquivo no Supabase SQL Editor ANTES de publicar a versão final.
-- Ele é idempotente nas partes de schema/policies nomeadas.

-- 1) Desabafos: estado de moderação.
alter table public.cae_vents
  add column if not exists status text not null default 'pending',
  add column if not exists moderated_at timestamptz,
  add column if not exists moderated_by uuid references auth.users(id);

update public.cae_vents
set status = 'approved'
where status is null;

alter table public.cae_vents
  drop constraint if exists cae_vents_status_check;

alter table public.cae_vents
  add constraint cae_vents_status_check
  check (status in ('pending','approved','rejected'));

create index if not exists cae_vents_status_created_idx
  on public.cae_vents(status, created_at desc);

-- 2) Função de staff para RLS.
create or replace function public.cae_is_staff()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.cae_profiles p
    where p.user_id = auth.uid()
      and p.role in ('admin','moderator')
  );
$$;

revoke all on function public.cae_is_staff() from public;
grant execute on function public.cae_is_staff() to authenticated;

-- 3) RLS dos desabafos.
alter table public.cae_vents enable row level security;

drop policy if exists "cae_vents_select_own_or_staff_final" on public.cae_vents;
create policy "cae_vents_select_own_or_staff_final"
on public.cae_vents for select
to authenticated
using (user_id = auth.uid() or public.cae_is_staff());

drop policy if exists "cae_vents_insert_own_final" on public.cae_vents;
create policy "cae_vents_insert_own_final"
on public.cae_vents for insert
to authenticated
with check (user_id = auth.uid());

drop policy if exists "cae_vents_update_staff_final" on public.cae_vents;
create policy "cae_vents_update_staff_final"
on public.cae_vents for update
to authenticated
using (public.cae_is_staff())
with check (public.cae_is_staff());

drop policy if exists "cae_vents_delete_own_or_staff_final" on public.cae_vents;
create policy "cae_vents_delete_own_or_staff_final"
on public.cae_vents for delete
to authenticated
using (user_id = auth.uid() or public.cae_is_staff());

-- 4) Exclusão de publicações pelo autor ou pela moderação.
alter table public.cae_posts enable row level security;

drop policy if exists "cae_posts_delete_own_or_staff_final" on public.cae_posts;
create policy "cae_posts_delete_own_or_staff_final"
on public.cae_posts for delete
to authenticated
using (user_id = auth.uid() or public.cae_is_staff());

-- 5) Storage dos áudios: autor e staff podem operar nos próprios/necessários objetos.
-- Os objetos do CAE seguem o padrão: <user_id>/<uuid>.<ext>.
drop policy if exists "cae_audio_staff_read_final" on storage.objects;
create policy "cae_audio_staff_read_final"
on storage.objects for select
to authenticated
using (
  bucket_id = 'cae-audios'
  and (
    (storage.foldername(name))[1] = auth.uid()::text
    or public.cae_is_staff()
  )
);

drop policy if exists "cae_audio_staff_delete_final" on storage.objects;
create policy "cae_audio_staff_delete_final"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'cae-audios'
  and (
    (storage.foldername(name))[1] = auth.uid()::text
    or public.cae_is_staff()
  )
);

-- 6) Bloqueio de contas não institucionais no cadastro.
-- IMPORTANTE: o domínio exigido pelo CAE nesta versão é literalmente @escola.
-- Se a escola usar outro domínio institucional, altere esta string no SQL
-- e também SCHOOL_EMAIL_DOMAIN no script.js.
create or replace function public.cae_require_school_email()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.email is null or lower(new.email) not like '%@escola' then
    raise exception 'CAE_SCHOOL_EMAIL_REQUIRED';
  end if;
  return new;
end;
$$;

drop trigger if exists cae_require_school_email_on_signup on auth.users;
create trigger cae_require_school_email_on_signup
before insert on auth.users
for each row
execute function public.cae_require_school_email();

-- 7) Índice útil para a fila de moderação.
create index if not exists cae_posts_status_created_idx
  on public.cae_posts(status, created_at desc);

-- Fim.
